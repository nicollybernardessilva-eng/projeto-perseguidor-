// Variaveis Globais
let cor;
let posicaoVertical;
let posicaoHorizontal;

function setup() {
  createCanvas(400, 400);
  cor =color (255,0,0)
  posicaoVertical = 200;
  posicaoHorizontal = 200;
}

function draw() {
  background(255);
  fill(cor);
  circle(posicaoVertical,posicaoHorizontal, 25)
  
  //-------Eixo y-------
  if(mouseY < posicaoHorizontal){
    posicaoHorizontal--;
  }
  if(mouseY > posicaoHorizontal){
    posicaoHorizontal ++;
  }
  if(mouseX < posicaoVertical){
    posicaoVertical--;
    }
  if(mouseX > posicaoVertical){
    posicaoVertical++;
  }
}